var Greeter = artifacts.require("./Greeter.sol");
var test = artifacts.require("./DemoTypes.sol");
module.exports = function(deployer) {
deployer.deploy(Greeter,"hellow world!");
deployer.deploy(test);
};
