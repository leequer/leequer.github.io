module.exports = {
  // See <http://truffleframework.com/docs/advanced/configuration>
  // to customize your Truffle configuration!
   networks: {
	development: {
	host: "localhost",
	port: 8545,
        gas:4712388, //Gas limit used for deploys. Default is web3.eth.getBlock(“pending”).gasLimit==4712388.
	gasPrice:18000000000, //Gas price used for deploys. Default is 100000000000 (100 Shannon).

	network_id: "*" // 匹配任何network id
	}
}
};
